<footer>
  &copy; <?php echo date('Y'); ?> T-Model
</footer>

</body>
</html>